﻿Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports System.Collections
Imports System.Collections.Specialized
Imports System.Text
Imports System.Net.Mail
Imports System.IO
Public Class EmailHelper

    Public Shared Sub Mail(ByVal fromEmail As String, ByVal toEmail As String, ByVal subject As String, ByVal body As String)
        Mail(fromEmail, toEmail, subject, body, "")
    End Sub

    Public Shared Sub Mail(ByVal fromEmail As String, ByVal toEmail As String, ByVal subject As String, ByVal body As String, ByVal bodyHTML As String)
        Dim parts As String() = toEmail.Split(New Char() {";"c})
        For i As Integer = 0 To parts.Length - 1
            Try
                ' Email it out
                Dim objMsg As New System.Net.Mail.MailMessage(fromEmail, parts(i))
                objMsg.Subject = subject


                If bodyHTML.Length > 0 Then
                    'this is the case of the html view
                    Dim plainView As System.Net.Mail.AlternateView = System.Net.Mail.AlternateView.CreateAlternateViewFromString(body, Nothing, System.Net.Mime.MediaTypeNames.Text.Plain)
                    objMsg.AlternateViews.Add(plainView)

                    Dim htmlView As System.Net.Mail.AlternateView = System.Net.Mail.AlternateView.CreateAlternateViewFromString(bodyHTML, Nothing, System.Net.Mime.MediaTypeNames.Text.Html)
                    htmlView.TransferEncoding = System.Net.Mime.TransferEncoding.Base64
                    objMsg.AlternateViews.Add(htmlView)
                Else
                    objMsg.Body = body
                    objMsg.IsBodyHtml = False
                End If

                objMsg.From = New MailAddress("info@gotequine.com", "GotEquine")
                'Proper Authentication Details need to be passed when sending email from gmail
                Dim mailAuthentication As New System.Net.NetworkCredential("info@gotequine.com", "monkey12")

                Dim smtpMail As New SmtpClient("smtp.gmail.com", 587)
                   'Enable SSL
                smtpMail.EnableSsl = True
                smtpMail.DeliveryMethod = SmtpDeliveryMethod.Network
                smtpMail.UseDefaultCredentials = False
                smtpMail.Credentials = mailAuthentication
                smtpMail.Send(objMsg)
            Catch e As Exception
                Dim file As New FileStream("C:\svr\gotequine.com\logs\EMAILERRORS\mail.txt", FileMode.Append, FileAccess.Write)
                Dim sw As New StreamWriter(file)
                sw.Write("##################### ERROR START ######################" & vbCr & vbLf)
                sw.Write("Error: " & e.Message() & vbCr & vbLf)
                sw.Write("From: " & fromEmail & vbCr & vbLf)
                sw.Write("To: " & parts(i) & vbCr & vbLf)
                sw.Write("Subject: " & subject & vbCr & vbLf)
                sw.Write("Body : " & body & vbCr & vbLf)
                sw.Write(bodyHTML & vbCr & vbLf)
                sw.Write("#####################  ERROR END  ######################" & vbCr & vbLf)
                sw.Close()
            End Try

            ' We need to log this email
            'Try
            '    Dim file As New FileStream(HttpContext.Current.Server.MapPath("mail.txt"), FileMode.Append, FileAccess.Write)
            '    Dim sw As New StreamWriter(file)
            '    sw.Write("From: " & fromEmail & vbCr & vbLf)
            '    sw.Write("To: " & parts(i) & vbCr & vbLf)
            '    sw.Write("Subject: " & subject & vbCr & vbLf)
            '    sw.Write("Body : " & body & vbCr & vbLf)
            '    sw.Write(bodyHTML & vbCr & vbLf)
            '    sw.Close()
            'Catch e As Exception

            'End Try
        Next
    End Sub
End Class

