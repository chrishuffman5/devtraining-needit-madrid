﻿Imports Microsoft.VisualBasic
Imports System.Data
Imports System.Data.SqlClient
Imports System.Data.SqlDbType
Imports System.Configuration
Imports System.Collections.Generic


Public Class DataAccessObject
    Private _isSQL As Boolean = False
    Private _storeProcedureOrSQLStatment As String = ""
    Private _itemsList As List(Of ItemParameters) = New List(Of ItemParameters)

    Public Property storeProcedureOrSQLStatment() As String
        Get
            Return _storeProcedureOrSQLStatment
        End Get
        Set(ByVal value As String)
            _storeProcedureOrSQLStatment = value
        End Set
    End Property
    Public Property itemsList() As List(Of ItemParameters)
        Get
            Return (_itemsList)
        End Get
        Set(ByVal value As List(Of ItemParameters))
            _itemsList = value
        End Set
    End Property
    Public Property isSQL() As Boolean
        Get
            Return _isSQL
        End Get
        Set(ByVal value As Boolean)
            _isSQL = value
        End Set
    End Property
    Public Sub New(ByVal storeProcedureOrSQLStatment As String)
        _storeProcedureOrSQLStatment = storeProcedureOrSQLStatment
    End Sub
    Public Sub New(ByVal storeProcedureOrSQLStatment As String, ByVal isSQL As Boolean)
        Me.New(storeProcedureOrSQLStatment)
        _isSQL = isSQL
    End Sub
    Public Sub New(ByVal storeProcedureOrSQLStatment As String, ByVal itemlist As List(Of ItemParameters))
        _storeProcedureOrSQLStatment = storeProcedureOrSQLStatment
        _itemsList = itemlist
    End Sub
    Public Sub New(ByVal storeProcedureOrSQLStatment As String, ByVal itemList As List(Of ItemParameters), ByVal isSQL As Boolean)
        Me.New(storeProcedureOrSQLStatment, itemList)
        _isSQL = isSQL
    End Sub

    Public Function getDataTable() As DataTable
        Dim myConnection As SqlConnection = New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("conn"))
        Dim dt As New DataTable
        Dim myCommand As SqlCommand = New SqlCommand(storeProcedureOrSQLStatment(), myConnection)

        If _isSQL = False Then
            myCommand.CommandType = CommandType.StoredProcedure
        End If

        ' Add Parameters
        If (itemsList().Count > 0) Then
            For Each item As ItemParameters In itemsList
                Dim parameter As SqlParameter
                parameter = New SqlParameter("@" & item.key, item.type)
                parameter.Value = item.value
                myCommand.Parameters.Add(parameter)
            Next
        End If
        Try
            myConnection.Open()
            Dim da As New SqlDataAdapter(myCommand)
            da.Fill(dt)
            myConnection.Close()
        Catch ex As Exception

        Finally
            If myConnection.State <> ConnectionState.Closed Then
                myConnection.Close()
            End If
        End Try
        Return dt
    End Function

    Public Function getLargeStringValue() As String
        Dim myConnection As SqlConnection = New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("conn"))
        Dim sb As New StringBuilder
        Try
            Dim myCommand As SqlCommand = New SqlCommand(storeProcedureOrSQLStatment(), myConnection)
            myConnection.Open()
            Dim reader As SqlDataReader = myCommand.ExecuteReader()

            While (reader.Read())
                sb.Append(reader.GetSqlString(0).Value)
            End While
            myConnection.Close()
        Catch ex As Exception

        Finally
            If myConnection.State <> ConnectionState.Closed Then
                myConnection.Close()
            End If
        End Try
        Return sb.ToString
    End Function

    Public Function getDataTableByConnectionName(ByVal conn As String) As DataTable
        Dim myConnection As SqlConnection = New SqlConnection(System.Configuration.ConfigurationManager.AppSettings(conn))
        Dim dt As New DataTable
        Dim myCommand As SqlCommand = New SqlCommand(storeProcedureOrSQLStatment(), myConnection)

        If _isSQL = False Then
            myCommand.CommandType = CommandType.StoredProcedure
        End If

        ' Add Parameters
        If (itemsList().Count > 0) Then
            For Each item As ItemParameters In itemsList
                Dim parameter As SqlParameter
                parameter = New SqlParameter("@" & item.key, item.type)
                parameter.Value = item.value
                myCommand.Parameters.Add(parameter)
            Next
        End If
        Try
            myConnection.Open()
            Dim da As New SqlDataAdapter(myCommand)
            da.Fill(dt)
            myConnection.Close()
        Catch ex As Exception

        Finally
            If myConnection.State <> ConnectionState.Closed Then
                myConnection.Close()
            End If
        End Try
        Return dt
    End Function

    Public Function getDataSet() As DataSet
        Dim myConnection As SqlConnection = New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("conn"))

        Dim ds As New DataSet
        Dim myCommand As SqlCommand = New SqlCommand(storeProcedureOrSQLStatment(), myConnection)
        If _isSQL = False Then
            myCommand.CommandType = CommandType.StoredProcedure
        End If

        ' Add Parameters
        If (itemsList().Count > 0) Then
            For Each item As ItemParameters In itemsList
                Dim parameter As SqlParameter
                parameter = New SqlParameter("@" & item.key, item.type)
                parameter.Value = item.value
                myCommand.Parameters.Add(parameter)
            Next
        End If

        ' Execute the command
        Try
            myConnection.Open()
            Dim da As New SqlDataAdapter(myCommand)
            da.Fill(ds)
            myConnection.Close()
        Catch ex As Exception

        Finally
            If myConnection.State <> ConnectionState.Closed Then
                myConnection.Close()
            End If
        End Try
        Return ds
    End Function
    Public Function Delete() As String
        Dim message As String = "Item deleted"
        Dim myConnection As SqlConnection = New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("conn"))

        Dim myCommand As SqlCommand = New SqlCommand(storeProcedureOrSQLStatment(), myConnection)
        If _isSQL = False Then
            myCommand.CommandType = CommandType.StoredProcedure
        End If

        ' Add Parameters
        If (itemsList().Count > 0) Then
            For Each item As ItemParameters In itemsList
                Dim parameter As SqlParameter
                parameter = New SqlParameter("@" & item.key, item.type)
                parameter.Value = item.value
                myCommand.Parameters.Add(parameter)
            Next
        End If

        ' Execute the command
        Try
            myConnection.Open()
            myCommand.ExecuteNonQuery()
            myConnection.Close()
        Catch ex As Exception
            message = ex.Message.ToString()
        Finally
            If myConnection.State <> ConnectionState.Closed Then
                myConnection.Close()
            End If
        End Try

        Return message
    End Function

    Public Function getGenericData() As Object
        Dim myConnection As SqlConnection = New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("conn"))

        Dim obj As New Object
        Return obj
    End Function
    Public Function InsertData() As String
        Dim message As String = ""
        Dim myConnection As SqlConnection = New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("conn"))

        Dim myCommand As SqlCommand = New SqlCommand(storeProcedureOrSQLStatment(), myConnection)
        If _isSQL = False Then
            myCommand.CommandType = CommandType.StoredProcedure
        End If

        ' Add Parameters
        If (itemsList().Count > 0) Then
            For Each item As ItemParameters In itemsList
                Dim parameter As SqlParameter
                parameter = New SqlParameter("@" & item.key, item.type)
                If item.value = "" Then
                    parameter.Value = DBNull.Value
                Else
                    parameter.Value = item.value
                End If
                myCommand.Parameters.Add(parameter)
            Next
        End If
        ' Execute the command
        Try
            myConnection.Open()
            Dim id As Integer = Convert.ToInt32(myCommand.ExecuteScalar().ToString)
            message = id.ToString()

            'myCommand.ExecuteNonQuery()
            myConnection.Close()
        Catch ex As Exception
            message = ex.Message.ToString()
        Finally
            If myConnection.State <> ConnectionState.Closed Then
                myConnection.Close()
            End If
        End Try

        Return message
    End Function
	
	Public Function ExecuteAdoNonQuery(ConnectionString as String) As String
        Dim message As String = ""
        Dim myConnection As SqlConnection = New SqlConnection(System.Configuration.ConfigurationManager.AppSettings(ConnectionString))

        Dim myCommand As SqlCommand = New SqlCommand(storeProcedureOrSQLStatment(), myConnection)
        If _isSQL = False Then
            myCommand.CommandType = CommandType.StoredProcedure
        End If

        ' Add Parameters
        If (itemsList().Count > 0) Then
            For Each item As ItemParameters In itemsList
                Dim parameter As SqlParameter
                parameter = New SqlParameter("@" & item.key, item.type)
                If item.value = "" Then
                    parameter.Value = DBNull.Value
                Else
                    parameter.Value = item.value
                End If
                myCommand.Parameters.Add(parameter)
            Next
        End If
        ' Execute the command
        Try
            myConnection.Open()
            Dim id As Integer = Convert.ToInt32(myCommand.ExecuteScalar().ToString)
            message = id.ToString()

            'myCommand.ExecuteNonQuery()
            myConnection.Close()
        Catch ex As Exception
            message = ex.Message.ToString()
        Finally
            If myConnection.State <> ConnectionState.Closed Then
                myConnection.Close()
            End If
        End Try

        Return message
    End Function
    'insert and updates are the basically the same thing at the moment
    'we could write a new update if the need is
    Public Function updateData() As String
        Return InsertData()
    End Function
End Class
