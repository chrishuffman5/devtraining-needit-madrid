﻿Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Collections
Imports System.Collections.Specialized
Imports System.IO
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Net

Public Class FileReader
    Public Shared Function read(ByVal filename As String) As String
        Dim template_name As String = ""

        If filename.LastIndexOf("/") > -1 Then
            template_name = filename.Substring(filename.LastIndexOf("/"c) + 1, filename.Length - filename.LastIndexOf("/"c) - 1)
        Else
            template_name = filename
        End If
        Dim template As String = ""
        Try
            Dim sr As New StreamReader(HttpContext.Current.Server.MapPath(filename))
            Dim strtemplate As New StringBuilder()
            strtemplate.Append(sr.ReadToEnd())
            sr.Close()

            template = strtemplate.ToString()
        Catch mye As Exception
        End Try
        Return template
    End Function

    Public Shared Function readAbsolute(ByVal filename As String) As String
        Try
            Dim sr As New StreamReader(filename)
            Dim strtemplate As New StringBuilder()
            strtemplate.Append(sr.ReadToEnd())
            sr.Close()
            Return strtemplate.ToString()
        Catch e As Exception
            Return ""
        End Try
    End Function
End Class
