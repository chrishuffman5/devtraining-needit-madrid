﻿Imports Microsoft.VisualBasic
Imports System.Data
Imports System.Data.SqlClient
Imports System.Data.SqlDbType
Imports System.Configuration
Imports System.Collections.Generic

Public Class ItemParameters
    Private _myKey As String = ""
    Private _myValue As String = ""
    Private _myType As SqlDbType

    Public Property key() As String
        Get
            Return _myKey
        End Get
        Set(ByVal value As String)
            _myKey = value
        End Set
    End Property
    Public Property value() As String
        Get
            Return _myValue
        End Get
        Set(ByVal value As String)
            _myValue = value
        End Set
    End Property
    Public Property type() As SqlDbType
        Get
            Return _myType
        End Get
        Set(ByVal value As SqlDbType)
            _myType = value
        End Set
    End Property
    Public Sub New(ByVal key As String, ByVal value As String, ByVal type As SqlDbType)
        _myKey = key
        _myValue = value
        _myType = type
    End Sub

End Class
